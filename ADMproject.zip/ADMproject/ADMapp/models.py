from django.db import models


class students_details(models.Model):
    student_id=models.CharField(max_length=20)
    firstname=models.CharField(max_length=20)
    middlename=models.CharField(blank=True,null=True,max_length=20)
    lastname=models.CharField(max_length=20)
    branch=models.CharField(max_length=6)
    section=models.CharField(max_length=1,blank=True,null=True)
    DOB=models.DateField()
    gender=models.CharField(max_length=20)
    student_phone_no=models.IntegerField()
    student_email_id=models.CharField(max_length=20)

    L_hno=models.CharField(blank=True,null=True,max_length=20)
    L_street=models.CharField(max_length=20)
    L_city=models.CharField(max_length=20)
    L_district = models.CharField(max_length=20,default="NA")
    L_state=models.CharField(max_length=20)
    L_pincode=models.IntegerField()

    P_hno=models.CharField(max_length=20)
    P_street=models.CharField(max_length=20)
    P_city=models.CharField(max_length=20)
    P_district = models.CharField(max_length=20,default="NA")
    P_state=models.CharField(max_length=20)
    P_pincode=models.IntegerField()

    bloodgroup = models.CharField(blank=True, null=True, max_length=20)
    aadhar_number=models.IntegerField()
    category=models.CharField(max_length=1)  # allotted category A or B
    religion=models.CharField(max_length=20)
    caste=models.CharField(max_length=20)
    reservation_category=models.CharField(max_length=20)
    allotted_category=models.CharField(max_length=20)  # OC,EWS, OBC, Girls etc
    blood_group=models.CharField(blank=True,null=True,max_length=20)
    ph_status=models.CharField(max_length=20)
    submission_status=models.CharField(blank=True,null=True,max_length=20)
    approved_by=models.CharField(blank=True,null=True,max_length=20)
    active_status=models.CharField(blank=True,null=True,max_length=20)
    created_on = models.DateField(auto_now_add=True,blank=True,null=True)
    counseling = models.IntegerField(blank=True,null=True)
    aadhar_certificate = models.FileField(upload_to='static/media/student_files')
    caste_certificate= models.FileField(upload_to='static/media/student_files')
    allotment_order= models.FileField(upload_to='static/media/student_files')
    transfer_certificate= models.FileField(upload_to='static/media/student_files')
    income_proof= models.FileField(upload_to='static/media/student_files')
    student_passportsize_photo= models.FileField(upload_to='static/media/student_files')
    ph_proof= models.FileField(upload_to='static/media/student_files',blank=True,null=True)

class education_details(models.Model):
    student_id=models.CharField(max_length=20)
    exam_hallticket_number=models.CharField(max_length=20)
    provisional_certificate_number=models.CharField(max_length=20)
    qualification=models.CharField(max_length=20)
    course_name=models.CharField(blank=True,null=True,max_length=20)
    institute_name=models.CharField(max_length=20)
    institute_city=models.CharField(max_length=20)
    institute_state=models.CharField(max_length=20)
    YOP=models.DateField() # year of passing
    board=models.CharField(max_length=30)
    marks_obtained=models.IntegerField()
    total_marks=models.IntegerField()
    percentage = models.DecimalField(max_digits=5, decimal_places=2)
    cgpa=models.DecimalField(max_digits=5, decimal_places=2)
    provisional_certificate=models.FileField(upload_to='static/media/education_files')


class parents_details(models.Model):
    student_id=models.CharField(max_length=20)
    father_name=models.CharField(max_length=40,blank=True,null=True)
    father_qualification=models.CharField(max_length=20,blank=True,null=True)
    father_occupation=models.CharField(max_length=20,blank=True,null=True)
    father_phone_number=models.IntegerField(blank=True,null=True)
    mother_name=models.CharField(max_length=40,blank=True,null=True)
    mother_qualification=models.CharField(max_length=20,blank=True,null=True)
    mother_occupation=models.CharField(max_length=20,blank=True,null=True)
    mother_phone_number=models.IntegerField(blank=True,null=True)
    guardian_name=models.CharField(max_length=40,blank=True,null=True)
    guardian_qualification=models.CharField(max_length=20,blank=True,null=True)
    guardian_occupation=models.CharField(max_length=20,blank=True,null=True)
    guardian_phone_number=models.IntegerField(blank=True,null=True)
    parent_email=models.CharField(max_length=30)

class CET_details(models.Model):
    student_id=models.CharField(max_length=20,blank=True,null=True)
    test_name=models.CharField(max_length=20,blank=True,null=True)
    hallticket_number=models.CharField(max_length=20,blank=True,null=True)
    test_date=models.DateField(blank=True,null=True)
    rank_obtained=models.IntegerField(blank=True,null=True)
    rank_card=models.FileField(upload_to='static/media/CET_files',blank=True,null=True)

class office_members(models.Model):
    office_member_id=models.CharField(max_length=20,blank=True,null=True)
    fullname=models.CharField(max_length=20,blank=True,null=True)
    email_id=models.CharField(max_length=20,blank=True,null=True)
    designation=models.CharField(max_length=20,blank=True,null=True)
    contact_number=models.IntegerField(blank=True,null=True)