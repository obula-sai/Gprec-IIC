from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(students_details)
admin.site.register(education_details)
admin.site.register(parents_details)
admin.site.register(CET_details)
admin.site.register(office_members)
