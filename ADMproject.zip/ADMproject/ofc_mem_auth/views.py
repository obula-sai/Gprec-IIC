from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
def register(request):
    if request.method=='POST':
        office_member_id=request.POST['office_member_id']
        fullname=request.POST['fullname']
        email=request.POST['email']
        designation=request.POST['designation']
        contact_number=request.POST['contact_number']
        pw1=request.POST['password1']
        pw2=request.POST['password2']
        if pw1==pw2:
            if User.objects.filter(email=email).exists():
                messages.info('Email already exists!!')
                return redirect('resgister')
            elif User.objects.filter(username=office_member_id).exists():
                messages.info('User already exists!!')
                return redirect('resgister')
            else:
             office_member_id=User.objects.create_user(username=office_member_id,email=email,password=pw1)
             office_member_id.save()
             return redirect('login')
        else:
            messages.info(request, 'Password doesnt match!')
            return redirect('register')
    return render(request,'register.html')
def login(request):
    if request.method=='POST':
        office_member_id=request.POST['office_member_id']
        pw=request.POST['password1']
        office_member_id=auth.authenticate(username=office_member_id, password=pw)
        if office_member_id is not None:
            auth.login(request,office_member_id)
            return render(request, 'user_login.html')
        else:
            messages.info(request,'Invalid user credentials!!')
            return redirect('login')
    else:
        return render(request,'login.html')
def logout(request):
    auth.logout(request)
    return redirect('/')
