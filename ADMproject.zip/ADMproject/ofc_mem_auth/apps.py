from django.apps import AppConfig


class OfcMemAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ofc_mem_auth'
