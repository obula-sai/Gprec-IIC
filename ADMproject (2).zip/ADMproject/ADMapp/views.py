from django.shortcuts import render,redirect,get_object_or_404
from datetime import datetime
from http.client import HTTPResponse
from django.contrib import messages

from .models import *
# Create your views here.
def home(request):
    if request.method=='POST':
        fname=request.POST['fname']
        mname=request.POST['mname']
        lname=request.POST['lname']
        branch_applying=request.POST['branch_applying']
        DOB=request.POST['DOB']
        gender=request.POST['gender']
        mobile_number=request.POST['mobile_number']
        email=request.POST['email']
        l_hno=request.POST['l_hno']
        l_street=request.POST['l_street']
        l_city=request.POST['l_city']
        l_district=request.POST['l_district']
        l_state=request.POST['l_state']
        l_pincode=request.POST['l_pincode']
        p_hno=request.POST['p_hno']
        p_street=request.POST['p_street']
        p_city=request.POST['p_city']
        p_district=request.POST['p_district']
        p_state=request.POST['p_state']
        p_pincode=request.POST['p_pincode']
        aadhar_number=request.POST['aadhar_number']
        category=request.POST['category']
        religion=request.POST['religion']
        caste=request.POST['caste']
        reservation_category=request.POST['reservation_category']
        allotted_category=request.POST['allotted_category']
        blood_group=request.POST['blood_group']
        ph_status=request.POST['ph_status']

        s_roll=request.POST['s_roll']
        s_pc_number=request.POST['s_pc_number']
        s_qualification=request.POST['s_qualification']
        s_institute_name=request.POST['s_institute_name']
        s_institute_city=request.POST['s_institute_city']
        s_institute_state=request.POST['s_institute_state']
        s_YOP=request.POST['s_YOP']
        s_board=request.POST['s_board']
        s_marks_obtained=request.POST['s_marks_obtained']
        s_total_marks=request.POST['s_total_marks']
        s_percentage=request.POST['s_percentage']
        s_cgpa=request.POST['s_cgpa']
        s_percentage=  float(s_percentage)
        s_cgpa=  float(s_cgpa)


        h_roll=request.POST['h_roll']
        h_pc_number=request.POST['h_pc_number']
        h_qualification=request.POST['h_qualification']
        h_course=request.POST['h_course']
        h_institute_name=request.POST['h_institute_name']
        h_institute_city=request.POST['h_institute_city']
        h_institute_state=request.POST['h_institute_state']
        h_YOP=request.POST['h_YOP']
        h_board=request.POST['h_board']
        h_marks_obtained=request.POST['h_marks_obtained']
        h_total_marks=request.POST['h_total_marks']
        h_percentage=request.POST['h_percentage']
        h_cgpa=request.POST['h_cgpa']
        h_percentage=  float(h_percentage)
        h_cgpa= float(h_cgpa)

        father_name=request.POST['father_name']
        father_qualification=request.POST['father_qualification']
        father_occupation=request.POST['father_occupation']
        father_phone=request.POST['father_phone']
        
        if father_phone:
            father_phone = int(father_phone)
        else:
            father_phone = None
        mother_name=request.POST['mother_name']
        mother_qualification=request.POST['mother_qualification']
        mother_occupation=request.POST['mother_occupation']
        mother_phone=request.POST['mother_phone']
        if mother_phone:
            mother_phone = int(mother_phone)
        else:
            mother_phone = None
        guardian_name=request.POST['guardian_name']
        guardian_qualification=request.POST['guardian_qualification']
        guardian_occupation=request.POST['guardian_occupation']
        guardian_phone=request.POST['guardian_phone']
        if guardian_phone:
            guardian_phone = int(guardian_phone)
        else:
            guardian_phone = None
        pg_email=request.POST['pg_email']

        e_test_name=request.POST['e_test_name']
        e_hallticket_number=request.POST['e_hallticket_number']
        #e_test_date=request.POST['e_test_date']
        e_test_date = datetime.strptime(request.POST['e_test_date'], '%Y-%m-%d').date() if request.POST.get('e_test_date') else None
        e_rank_obtained=request.POST['e_rank_obtained']
        if e_rank_obtained:
            e_rank_obtained = int(e_rank_obtained)
        else:
            e_rank_obtained = None       

        j_test_name=request.POST['j_test_name']
        j_hallticket_number=request.POST['j_hallticket_number']
        # j_test_date=request.POST['j_test_date']
        j_test_date = datetime.strptime(request.POST['j_test_date'], '%Y-%m-%d').date() if request.POST.get('j_test_date') else None
        j_rank_obtained=request.POST['j_rank_obtained']
        if j_rank_obtained:
            j_rank_obtained = int(j_rank_obtained)
        else:
            j_rank_obtained = None


        aadhar_doc=request.FILES['aadhar_doc']
        caste_doc=request.FILES['caste_doc']
        aj_docs=request.FILES['aj_docs']
        tc_doc=request.FILES['tc_doc']
        ir_doc=request.FILES['ir_doc']
        student_photo=request.FILES['student_photo']
        ph_doc = request.FILES.get('ph_doc', None)
        s_pc_doc=request.FILES['s_pc_doc']
        h_pc_doc=request.FILES['h_pc_doc']

        e_rank_card=request.FILES.get('e_rank_card', None)
        j_rank_card = request.FILES.get('j_rank_card', None)
        existing_student = students_details.objects.filter(aadhar_number=aadhar_number).first()
        if existing_student:
            messages.info(request, "Student has already filled the admission form!!")
            return redirect("display")
        else:
            SD=students_details(student_id=aadhar_number,firstname=fname,middlename=mname,lastname=lname,branch=branch_applying,DOB=DOB,gender=gender,student_phone_no=mobile_number,student_email_id=email,L_hno=l_hno,L_street=l_street,L_city=l_city,L_district=l_district,L_state=l_state,L_pincode=l_pincode,P_hno=p_hno,P_street=p_street,P_city=p_city,P_district=p_district,P_state=p_state,P_pincode=p_pincode,aadhar_number=aadhar_number,category=category,religion=religion,caste=caste,reservation_category=reservation_category,allotted_category=allotted_category,bloodgroup=blood_group,ph_status=ph_status,aadhar_certificate=aadhar_doc,caste_certificate=caste_doc,allotment_order=aj_docs,transfer_certificate=tc_doc,income_proof=ir_doc,student_passportsize_photo=student_photo,ph_proof=ph_doc)
            ED1=education_details(student_id=aadhar_number,exam_hallticket_number=s_roll,provisional_certificate_number=s_pc_number,qualification=s_qualification,institute_name=s_institute_name,institute_city=s_institute_city,institute_state=s_institute_state,YOP=s_YOP,board=s_board,marks_obtained=s_marks_obtained,total_marks=s_total_marks,percentage=float(s_percentage),cgpa=float(s_cgpa),provisional_certificate=s_pc_doc)
            ED2=education_details(student_id=aadhar_number,exam_hallticket_number=h_roll,provisional_certificate_number=h_pc_number,qualification=h_qualification,course_name=h_course,institute_name=h_institute_name,institute_city=h_institute_city,institute_state=h_institute_state,YOP=h_YOP,board=h_board,marks_obtained=h_marks_obtained,total_marks=h_total_marks,percentage=float(h_percentage),cgpa=float(h_cgpa),provisional_certificate=h_pc_doc)
            PD=parents_details(student_id=aadhar_number,father_name=father_name,father_qualification=father_qualification,father_occupation=father_occupation,father_phone_number=father_phone,mother_name=mother_name,mother_qualification=mother_qualification,mother_occupation=mother_occupation,mother_phone_number=mother_phone,guardian_name=guardian_name,guardian_qualification=guardian_qualification,guardian_occupation=guardian_occupation,guardian_phone_number=guardian_phone,parent_email=pg_email)
            CET2=CET_details(student_id=aadhar_number,test_name=j_test_name,hallticket_number=j_hallticket_number,test_date=j_test_date,rank_obtained=j_rank_obtained,rank_card=j_rank_card)
            CET1=CET_details(student_id=aadhar_number,test_name=e_test_name,hallticket_number=e_hallticket_number,test_date=e_test_date,rank_obtained=e_rank_obtained,rank_card=e_rank_card)
            SD.save()
            ED1.save()
            ED2.save()
            PD.save()
            CET1.save()
            CET2.save()
            request.session['sid']=aadhar_number    
            return redirect('display')
    return render(request,'index.html')

def display(request):
    if 'sid' in request.session:
        if request.method=='POST':
            an=request.session.get('sid')
            SD=students_details.objects.filter(student_id=an)
            ED1=education_details.objects.filter(student_id=an)
            ED2=education_details.objects.filter(student_id=an)
            PD=parents_details.objects.filter(student_id=an)
            CET2=CET_details.objects.filter(student_id=an)
            CET1=CET_details.objects.filter(student_id=an)
            del request.session['sid']
            return render(request,'display.html',{'SD':SD,'ED1':ED1,'ED2':ED2,'PD':PD,'CET1':CET1,'CET2':CET2})
        return render(request,'success.html')
    else:
        if request.method=='POST':
            an=request.POST['aadhar_number']
            SD=students_details.objects.filter(student_id=an)
            ED1=education_details.objects.filter(student_id=an)
            ED2=education_details.objects.filter(student_id=an)
            PD=parents_details.objects.filter(student_id=an)
            CET2=CET_details.objects.filter(student_id=an)
            CET1=CET_details.objects.filter(student_id=an)
            return render(request,'display.html',{'SD':SD,'ED1':ED1,'ED2':ED2,'PD':PD,'CET1':CET1,'CET2':CET2})
        return render(request,'entry.html')


def get_details(request):
    return render(request,'entry.html')




def student_d(request):
    # Get all students
    students = students_details.objects.all()

    # Initialize an empty list to store the final result
    result_list = []

    # Iterate through each student
    for student in students:
        # Simulate join with education_details using a filter
        education_details_record = education_details.objects.filter(student_id=student.student_id).first()

        # Simulate join with CET_details using a filter
        cet_details_record = CET_details.objects.filter(student_id=student.student_id).first()

        # Create a dictionary to store the combined information
        combined_info = {
            'aadhar_number': student.aadhar_number,
            'firstname': student.firstname,
            'student_phone_no': student.student_phone_no,
            'category': student.category,
            'allotted_category': student.allotted_category,
            'qualification': education_details_record.qualification if education_details_record else None,
            'test_name': cet_details_record.test_name if cet_details_record else None,
            'branch': student.branch,
            'approval_status': student.approval_status
        }

        # Append the dictionary to the result list
        result_list.append(combined_info)

    # Print or use the result_list as needed
    for i in result_list:
        print(i)

    return render(request, 'details.html')





